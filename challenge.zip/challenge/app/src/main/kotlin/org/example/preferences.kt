data class Preferences(
    val id: Int,
    val theme: String,
    val color: String,
    val categories: List<String>,
    val labels: List<String>
)