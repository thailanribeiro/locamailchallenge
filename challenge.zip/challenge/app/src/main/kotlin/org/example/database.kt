import org.sqlite.SQLiteDataSource

object Database {
    private val dataSource = SQLiteDataSource().apply {
        url = "jdbc:sqlite:preferences.db"
    }

    fun getConnection() = dataSource.connection
}