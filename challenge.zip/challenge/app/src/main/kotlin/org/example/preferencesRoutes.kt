package org.example

import io.ktor.application.*
import io.ktor.response.*
import io.ktor.request.*
import io.ktor.routing.*
import io.ktor.http.HttpStatusCode

data class Preferences(val theme: String, val color: String) // Exemplo de definição de Preferences

fun Route.preferencesRoutes() {
    route("/preferences") {
        get {
            call.respond(HttpStatusCode.OK, "List of preferences")
        }

        post {
            val preferences = call.receive<Preferences>()
            call.respond(HttpStatusCode.Created, preferences)
        }
    }
}

