package org.example

// Modelo para representar um e-mail
data class Email(
    val id: String,
    val subject: String,
    val body: String,
    val sender: String,
    val receiver: String
)