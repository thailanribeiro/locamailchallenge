package org.example

object SpamControl {
    private val emailSendCounts = mutableMapOf<String, Int>()

    fun isSpam(email: Email): Boolean {
        val count = emailSendCounts.getOrDefault(email.sender, 0)
        emailSendCounts[email.sender] = count + 1
        return count > 5 // Simples exemplo: considera spam se mais de 5 e-mails enviados
    }
}
