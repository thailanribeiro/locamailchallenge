package org.example

import io.ktor.application.*
import io.ktor.features.StatusPages
import io.ktor.http.HttpStatusCode
import io.ktor.response.*
import io.ktor.routing.*
import io.ktor.server.engine.embeddedServer
import io.ktor.server.netty.Netty
import io.ktor.features.ContentNegotiation
import io.ktor.jackson.jackson
import io.ktor.client.*
import io.ktor.client.engine.cio.*
import io.ktor.client.request.*
import io.ktor.client.statement.*
import kotlinx.coroutines.runBlocking

fun main() {
    embeddedServer(Netty, port = 8080, module = Application::module).start(wait = true)
}

fun Application.module() {
    install(ContentNegotiation) {
        jackson { }
    }

    install(StatusPages) {
        exception<Throwable> { cause ->
            call.respond(HttpStatusCode.InternalServerError, cause.localizedMessage)
        }
    }

    routing {
        emailRoutes() // Adiciona as rotas de e-mail
        preferencesRoutes() // Adiciona as rotas de preferências
    }
}

suspend fun fetchFromAPI() {
    val client = HttpClient(CIO)
    val response: String = client.get("http://localhost:3000/")
    println(response)
    client.close()
}

fun main() {
    runBlocking {
        fetchFromAPI() // Chama a função para realizar a requisição HTTP
    }
}