package org.example

import io.ktor.application.*
import io.ktor.response.*
import io.ktor.request.*
import io.ktor.routing.*
import io.ktor.http.HttpStatusCode
import org.example.Email // Importa a classe Email do arquivo email.kt
import org.example.SpamControl

fun Route.emailRoutes() {
    route("/emails") {
        get {
            call.respond(HttpStatusCode.OK, "List of emails")
        }

        post {
            val email = call.receive<Email>()
            if (SpamControl.isSpam(email)) {
                call.respond(HttpStatusCode.BadRequest, "Spam detected")
            } else {
                call.respond(HttpStatusCode.Created, email)
            }
        }
    }
}
